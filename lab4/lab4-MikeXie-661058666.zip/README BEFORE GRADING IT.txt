This app goes into your facebook account and looks at information that you allow to share publicly. 
In order to make the app experience relative to each user, I used facebook login, which requires that I register an app on facebook, and register the url of the app(site). The site url I registered on facebook is:
                                http://localhost/websci/lab4/
Please use the exact url to access to my lab, otherwise you wouldn't be able to log in to facebook through my app and of course no information from facebook about you would be displayed.
Sorry for the inconvenience! But I don't know any other way to implement facebook login. 