This script gets data from a json file and display the tweet data in the form of tweeter steam.
Every 3 seconds, a new feed adds to the current stream from the top.
The homework instruction is a bit ambiguous: should the stream complete a full cycle every 5 seconds or should it only grab one new tweet every three seconds. Anyway, I did the second way. 