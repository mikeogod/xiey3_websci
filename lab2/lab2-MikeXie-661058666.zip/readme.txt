Lab2

In this lab, I created a weather app that automatically displays weather information based on the user's geolocation. 
The entire app is totally front-end, and a big part of the appearance is henced by using Bootstrap.Also it is mobile friendly, which means the formatting won't be messed up when viewport changes to tablets/mobiles. It is accomplished by utilizing Bootstrap's flexible and responsive grid system.

Author: Mike Xie